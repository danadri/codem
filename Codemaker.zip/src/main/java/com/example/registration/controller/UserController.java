package com.example.registration.controller;


import com.example.registration.dto.UserDTO;
import com.example.registration.model.User;
import com.example.registration.security.MyUserDetailsService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class UserController {


    @Autowired
    MyUserDetailsService myUserDetailsService;


    @PostMapping("/login")
    public String login(@RequestParam("email") String email, @RequestParam("password") String pwd) {


        try{
            User user = myUserDetailsService.findUserByEmail(email);
            if (user.getPassword().equals(pwd)){

                String token = createJWTToken(email);
                return token;

            } else return "wrong credentials";

        }catch (UsernameNotFoundException e){
           return "User not found";
        }

    }


    @PostMapping("/signup")
    public void signUp(@RequestBody User user) {
        myUserDetailsService.addUser(user);

    }


    @GetMapping("/user/{email}")
    public UserDTO getUserDetails(@PathVariable String email){

        UserDTO userDTO = new UserDTO();
        User user = myUserDetailsService.findUserByEmail(email);

        userDTO.setName(user.getName());
        userDTO.setEmail(user.getEmail());
        userDTO.setAuthority(user.getAuthority());

        return userDTO;

    }



    private String createJWTToken(String email) {
        String secretKey = "SecretKey";

        List<GrantedAuthority> grantedAuthorities = AuthorityUtils
                .commaSeparatedStringToAuthorityList("ROLE_USER");

        String token = Jwts
                .builder()
                .setSubject(email)
                .claim("authorities",
                        grantedAuthorities.stream()
                                .map(GrantedAuthority::getAuthority)
                                .collect(Collectors.toList()))
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 6))
                .signWith(SignatureAlgorithm.HS512,
                        secretKey.getBytes()).compact();

        return "Bearer " + token;
    }

}
