package com.example.registration.security;

import com.example.registration.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.UserDetailsManager;

import java.util.ArrayList;
import java.util.List;


public class MyUserDetailsService  {

    List<User> userList = new ArrayList<>();


    public User findUserByEmail(String email) throws UsernameNotFoundException {

        User user = userList.stream()
                .filter(el -> el.getEmail().equals(email))
                .findFirst().orElseThrow(()->new UsernameNotFoundException("user not found"));

        return user;
    }

    public void addUser(User user){

        userList.add(user);
    }



}
